/*
 * Copyright 2010 Red Hat, Inc. and/or its affiliates.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.optaplanner.examples.curriculumcourse.persistence;

import java.io.IOException;


import org.optaplanner.examples.common.persistence.AbstractXmlSolutionExporter;
import org.optaplanner.examples.common.persistence.SolutionConverter;
import org.optaplanner.examples.curriculumcourse.app.CurriculumCourseApp;

import org.optaplanner.examples.curriculumcourse.domain.CourseSchedule;
import org.optaplanner.examples.curriculumcourse.domain.Lecture;
import org.jdom.Element;
public class CurriculumCourseExporter extends AbstractXmlSolutionExporter<CourseSchedule> {
    public static void main(String[] args) {
        SolutionConverter<CourseSchedule> converter = SolutionConverter.createExportConverter(
                CurriculumCourseApp.DATA_DIR_NAME, CourseSchedule.class, new CurriculumCourseExporter());
        converter.convertAll();
    }

    @Override
    public XmlOutputBuilder<CourseSchedule> createXmlOutputBuilder() {
        return new CurriculumCourseOutputBuilder();
    }

    public static class CurriculumCourseOutputBuilder extends XmlOutputBuilder<CourseSchedule> {
   private CourseSchedule courseSchedule;
   @Override
    public void setSolution(CourseSchedule solution) {
        courseSchedule=solution;
        
    }
        @Override
        public void writeSolution() throws IOException {
            Element solutionElement = new Element("Solution");
            document.setRootElement(solutionElement);
            for (Lecture lecture : courseSchedule.getLectureList()) {
//                bufferedWriter.write(lecture.getCourse().getCode()
//                        + " r" + lecture.getRoom().getCode()
//                        + " " + lecture.getPeriod().getDay().getDayIndex()
//                        + " " + lecture.getPeriod().getTimeslot().getTimeslotIndex() + "\r\n");
                 Element assignmentElement = new Element("CourseSchedule");
                 solutionElement.addContent(assignmentElement);
                 
                 Element lectureElement = new Element("Lecture");
                 lectureElement.setText(lecture.getCourse().getCode());
                 assignmentElement.addContent(lectureElement);
                 
                 Element lectureIdElement = new Element("LectureId");
                 lectureIdElement.setText(lecture.getCourse().getId1().toString());
                 assignmentElement.addContent(lectureIdElement);
                 
                 
                 Element roomElement = new Element("Room");
                 roomElement.setText(lecture.getRoom().getCode());
                 assignmentElement.addContent(roomElement);
                 
                 Element roomIdElement = new Element("RoomId");
                 roomIdElement.setText(lecture.getRoom().getId().toString());
                 assignmentElement.addContent(roomIdElement);
                 
                 Element weekElement = new Element("Week");
                 weekElement.setText(lecture.getWeek().getCode());
                 assignmentElement.addContent(weekElement);
                 
                 Element weekIdElement = new Element("WeekId");
                 weekIdElement.setText(lecture.getWeek().getId().toString());
                 assignmentElement.addContent(weekIdElement);
                 
                 
                 
                 Element weekdayElement = new Element("Weekday");
                 weekdayElement.setText(lecture.getPeriod().getDay().getAweek().getCode());
                assignmentElement.addContent(weekdayElement);
                 
                
                Element weekdayIdElement = new Element("WeekdayId");
                weekdayIdElement.setText(lecture.getPeriod().getDay().getAweek().getId().toString());
               assignmentElement.addContent(weekdayIdElement);
                
                
                Element timeslotElement = new Element("Nodes");
                timeslotElement.setText(lecture.getPeriod().getTimeslot().getCode());
               assignmentElement.addContent(timeslotElement);
               
               Element timeslotIdElement = new Element("NodesId");
               timeslotIdElement.setText(lecture.getPeriod().getTimeslot().getId().toString());
              assignmentElement.addContent(timeslotIdElement);
              
          
              
              Element coursenatureElement = new Element("Coursenature");
              coursenatureElement.setText(lecture.getCoursenature().getCode());
             assignmentElement.addContent(coursenatureElement);
             
             
              Element coursenatureIdElement = new Element("CoursenatureId");
              coursenatureIdElement.setText(lecture.getCoursenature().getId().toString());
             assignmentElement.addContent(coursenatureIdElement);
              
               Element teacherlotElement = new Element("Teacher");
               teacherlotElement.setText(lecture.getTeacher().getCode() );
              assignmentElement.addContent(teacherlotElement);
              
              Element teacherlotIdElement = new Element("TeacherId");
              teacherlotIdElement.setText(lecture.getTeacher().getId().toString() );
             assignmentElement.addContent(teacherlotIdElement);
             Element assignmentElement1= new Element("ClassList");
             assignmentElement.addContent(assignmentElement1);
              for (int i = 0; i < lecture.getCurriculumList().size(); i++) {
                
            	  Element assignmentElement2= new Element("Class");
            	
            	  assignmentElement1.addContent(assignmentElement2);
              Element curriculumlotElement = new Element("ClassName");
             
              curriculumlotElement.setText(lecture.getCurriculumList().get(i).getCode());
              assignmentElement2.addContent(curriculumlotElement);
              
         
                
                
                  Element curriculumlotIdElement = new Element("ClassId");
                 
                  curriculumlotIdElement.setText(lecture.getCurriculumList().get(i).getId().toString());
                  assignmentElement2.addContent(curriculumlotIdElement);
                  }
            }
        }

        
    }

}
