package org.optaplanner.examples.curriculumcourse.domain;

import org.optaplanner.examples.common.domain.AbstractPersistable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
@XStreamAlias("UnavailableRoomPenalty")
public class UnavailableRoomPenalty extends AbstractPersistable{
	private Subject subject;
    private Room room;
    private int weight;
    private Curriculum curriculum;
   	public Curriculum getCurriculum() {
   		return curriculum;
   	}
   	public void setCurriculum(Curriculum curriculum) {
   		this.curriculum = curriculum;
   	}
     
  	public int getWeight() {
  		return weight;
  	}
  	public void setWeight(int weight) {
  		this.weight = weight;
  	}


    public Subject getSubject() {
		return subject;
	}
	public void setSubject(Subject subject) {
		this.subject = subject;
	}
	public Room getRoom() {
        return room;
    }

    public void setRoom(Room room) {
        this.room = room;
    }

    @Override
    public String toString() {
        return subject + "@" + room+"@"+weight+"@"+curriculum;
    }

}
