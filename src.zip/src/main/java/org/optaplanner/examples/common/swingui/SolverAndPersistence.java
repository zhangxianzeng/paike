package org.optaplanner.examples.common.swingui;

import java.io.File;
import java.io.PrintStream;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;

import javax.swing.SwingWorker;

import org.optaplanner.core.api.solver.Solver;
import org.optaplanner.examples.common.business.SolutionBusiness;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SolverAndPersistence<Solution_> {
	protected final transient Logger logger = LoggerFactory.getLogger(getClass());

	private final SolutionBusiness<Solution_> solutionBusiness;

	public SolverAndPersistence(SolutionBusiness<Solution_> solutionBusiness) {
		this.solutionBusiness = solutionBusiness;
	}

	public String init(String path, PrintStream stddOut, PrintStream ps, int seconds) {
		File file = new File(path);
		try {
			solutionBusiness.openSolution(file);
		} catch (Exception e) {
			e.printStackTrace(ps);
			stddOut.println(0);
			return "File：" + file.getAbsolutePath() + " openSolution error!";
		}
		Solution_ planningProblem = solutionBusiness.getSolution();
		SolveWorker solveWorker = new SolveWorker(planningProblem);
		solveWorker.execute();
		// Thread thread = new Thread(new SolveWorker(planningProblem));
		// thread.start();
		if (seconds != 0) {
			try {
				Thread.sleep(seconds * 1000);
			} catch (InterruptedException e) {
				e.printStackTrace(ps);
				stddOut.println(0);
				return "Son thread error!--1";
			}
			solutionBusiness.terminateSolvingEarly();
			Solver<Solution_> solver = solutionBusiness.getSolver();
			if (solver.isTerminateEarly()) {
		        Solution_ solution = solver.getBestSolution();
		        solutionBusiness.setSolution(solution);
			}
			
//			try {
//				TimeUnit.SECONDS.timedJoin(thread, seconds);
//			} catch (Exception e) {
//				e.printStackTrace(ps);
//				stddOut.println(0);
//				return "Son thread error!";
//			}
//			if (thread.isAlive()) {
//				solutionBusiness.terminateSolvingEarly();
//				Solver<Solution_> solver = solutionBusiness.getSolver();
//				if (solver.isTerminateEarly()) {
//			        Solution_ solution = solver.getBestSolution();
//			        solutionBusiness.setSolution(solution);
//				}
//			}
		} else {
			while (true) {
				if (!solveWorker.getFlag()) {
					try {
						Thread.sleep(10 * 1000);
					} catch (InterruptedException e) {
						e.printStackTrace(ps);
						stddOut.println(0);
						return "Son thread error!--2";
					}
				} else {
					break;
				}
			}
			
//			try {
//				thread.join();
//			} catch (Exception e) {
//				e.printStackTrace(ps);
//				stddOut.println(0);
//				return "Son thread error!";
//			}
		}

		File exportFile = new File(path.replaceAll("\\.xml$", "") + "_solved.xml");
		try {
			solutionBusiness.exportSolution(exportFile);
		} catch (Exception e) {
			e.printStackTrace(ps);
			stddOut.println(0);
			return "Solution export error!";
		}
		stddOut.println(1);
		return exportFile.getAbsolutePath();
	}

	protected class SolveWorker2 implements Runnable {

		protected final Solution_ planningProblem;

		public SolveWorker2(Solution_ planningProblem) {
			this.planningProblem = planningProblem;
		}
		@Override
		public void run() {
			Solution_ bestSolution = solutionBusiness.solve(planningProblem);
			solutionBusiness.setSolution(bestSolution);
		}
	}
	
	protected class SolveWorker extends SwingWorker<Solution_, Void> {

        protected final Solution_ planningProblem;
        private boolean flag = false;

        public SolveWorker(Solution_ planningProblem) {
            this.planningProblem = planningProblem;
        }

        public boolean getFlag() {
        	return this.flag;
        }
        
        @Override
        protected Solution_ doInBackground() throws Exception {
            return solutionBusiness.solve(planningProblem);
        }

        @Override
        protected void done() {
            try {
                Solution_ bestSolution = get();
                solutionBusiness.setSolution(bestSolution);
                flag = true;
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                throw new IllegalStateException("Solving was interrupted.", e);
            } catch (ExecutionException e) {
                throw new IllegalStateException("Solving failed.", e.getCause());
            } finally {
            	System.out.println("Solved.");
            }
        }

    }
}
